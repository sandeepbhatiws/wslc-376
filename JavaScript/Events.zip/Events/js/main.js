
function onClickEvent(){
    alert();
}


function onOverMouse(){
    console.log('On Mouse Over');
}

function onOutMouse(){
    console.log('On Mouse Out');
}

function onMove(){
    console.log('On Move');
}

function getTextValue(text){
    console.log(text.value);
}