
// var output = document.getElementById('html').parentNode;
// console.log(output);

// var output = document.getElementById('html').parentElement;
// console.log(output);

// var output = document.getElementById('outer_courses').childNodes;
// console.log(output);

// var output = document.getElementById('outer_courses').children;
// console.log(output);

// var output = document.getElementById('outer_courses').firstChild;
// console.log(output);

// var output = document.getElementById('outer_courses').firstElementChild;
// console.log(output);

// var output = document.getElementById('outer_courses').lastChild;
// console.log(output);

// var output = document.getElementById('outer_courses').lastElementChild;
// console.log(output);

// var output = document.getElementById('courses1').hasChildNodes();
// console.log(output);

// var output = document.getElementById('row3').nextSibling;
// console.log(output);

// var output = document.getElementById('row3').nextElementSibling;
// console.log(output);

var output = document.getElementById('row3').previousSibling;
console.log(output);

var output = document.getElementById('row3').previousElementSibling;
console.log(output);